import assert from "node:assert/strict";
import test from "node:test";
import {
  assignmentModeForSeed,
  CHORE_CATALOG,
  SKIP_SHARD_REWARD,
  CHORE_CLAIM_STATUSES,
  compareClaimsForInbox,
  compareChoresForKid,
  compareChoresForParent,
} from "./choreCatalog.js";
import { choreClaimGate, choreOpenForFamily } from "./chores.js";

test("seed catalog has 27 unique slugs", () => {
  assert.equal(CHORE_CATALOG.length, 27);
  const slugs = CHORE_CATALOG.map((row) => row.slug);
  assert.equal(new Set(slugs).size, 27);
});

test("Set Out School Clothes is inactive; dog chores are CRITICAL races", () => {
  const clothes = CHORE_CATALOG.find((row) => row.slug === "set-out-school-clothes");
  assert.equal(clothes?.isActive, false);
  const dogs = CHORE_CATALOG.filter((row) =>
    ["feed-dog-am", "feed-dog-pm", "walk-the-dog"].includes(row.slug),
  );
  assert.equal(dogs.length, 3);
  for (const dog of dogs) {
    assert.equal(dog.priority, "CRITICAL");
    assert.equal(dog.isGlobal, false);
    assert.equal(assignmentModeForSeed(dog), "RACE");
  }
});

test("Brush Your Hair is a photo chore, not a global selfie earn", () => {
  const hair = CHORE_CATALOG.find((row) => row.slug === "brush-your-hair");
  assert.ok(hair);
  assert.equal(hair.requiresSelfie, true);
  assert.equal(hair.requiresApproval, true);
  assert.equal(hair.isGlobal, false);
});


test("after-school arrival chores are WEEKDAYS + AFTERNOON", () => {
  for (const slug of ["hang-backpack", "shoes-on-rack", "water-bottle-backpack"]) {
    const row = CHORE_CATALOG.find((r) => r.slug === slug);
    assert.ok(row, slug);
    assert.equal(row.recurrence, "WEEKDAYS");
    assert.equal(row.timeOfDay, "AFTERNOON");
    assert.equal(row.priority, "HIGH");
    assert.equal(row.includeInPath, true);
    assert.equal(row.isGlobal, true);
    assert.equal(assignmentModeForSeed(row), "ALL");
  }
});

test("may-need afternoon chores are DAILY + AFTERNOON", () => {
  const empty = CHORE_CATALOG.find((r) => r.slug === "empty-dishwasher");
  const hw = CHORE_CATALOG.find((r) => r.slug === "do-homework");
  const snack = CHORE_CATALOG.find((r) => r.slug === "clean-snack-mess");
  assert.ok(empty && hw && snack);
  for (const row of [empty, hw, snack]) {
    assert.equal(row.recurrence, "DAILY");
    assert.equal(row.timeOfDay, "AFTERNOON");
    assert.equal(row.includeInPath, true);
    assert.equal(row.allowsSkip, true);
  }
  assert.equal(empty.isGlobal, false);
  assert.equal(assignmentModeForSeed(empty), "RACE");
  assert.equal(hw.isGlobal, true);
  assert.equal(hw.priority, "HIGH");
  assert.equal(snack.isGlobal, true);
  assert.equal(empty.priority, "NORMAL");
  assert.equal(snack.priority, "NORMAL");
});

test("Walk the Dog and Easy Bedtime have short descriptions", () => {
  const walk = CHORE_CATALOG.find((row) => row.slug === "walk-the-dog");
  const bed = CHORE_CATALOG.find((row) => row.slug === "easy-bedtime");
  assert.ok((walk?.description ?? "").length > 10);
  assert.ok((bed?.description ?? "").length > 10);
});

test("isGlobal seeds ALL; otherwise RACE", () => {
  assert.equal(assignmentModeForSeed({ isGlobal: true }), "ALL");
  assert.equal(assignmentModeForSeed({ isGlobal: false }), "RACE");
});

test("parent catalog puts CRITICAL first even when sortOrder is later", () => {
  const rows = [
    { title: "Bed", priority: "NORMAL" as const, sortOrder: 1 },
    { title: "Feed Dog", priority: "CRITICAL" as const, sortOrder: 6 },
    { title: "Off chore", priority: "HIGH" as const, sortOrder: 2 },
  ];
  const sorted = [...rows].sort(compareChoresForParent);
  assert.equal(sorted[0]?.title, "Feed Dog");
  assert.equal(sorted[1]?.title, "Off chore");
});

test("kid list puts path + CRITICAL first", () => {
  const rows = [
    { title: "Z", includeInPath: false, priority: "NORMAL" as const, sortOrder: 9 },
    { title: "Feed", includeInPath: true, priority: "CRITICAL" as const, sortOrder: 6 },
    { title: "Bed", includeInPath: true, priority: "NORMAL" as const, sortOrder: 1 },
  ];
  const sorted = [...rows].sort(compareChoresForKid);
  assert.equal(sorted[0]?.title, "Feed");
  assert.equal(sorted[1]?.title, "Bed");
});

test("inbox sorts CRITICAL before older NORMAL claims", () => {
  const rows = [
    { priority: "NORMAL" as const, claimedAt: "2026-09-09T10:00:00.000Z" },
    { priority: "CRITICAL" as const, claimedAt: "2026-09-09T12:00:00.000Z" },
  ];
  const sorted = [...rows].sort(compareClaimsForInbox);
  assert.equal(sorted[0]?.priority, "CRITICAL");
});

test("claim gate blocks races, duplicates, weekends, and specific-without-assignment", () => {
  assert.equal(choreClaimGate({
    isActive: true,
    periodEligible: true,
    assignmentMode: "ALL",
    hasAssignment: false,
    alreadyClaimedByPlayer: false,
    raceTaken: false,
  }).ok, true);
  assert.equal(choreClaimGate({
    isActive: true,
    periodEligible: false,
    assignmentMode: "ALL",
    hasAssignment: false,
    alreadyClaimedByPlayer: false,
    raceTaken: false,
  }).ok, false);
  assert.equal(choreClaimGate({
    isActive: true,
    periodEligible: true,
    assignmentMode: "ALL",
    hasAssignment: false,
    alreadyClaimedByPlayer: true,
    raceTaken: false,
  }).reason, "You already claimed that chore.");
  assert.equal(choreClaimGate({
    isActive: true,
    periodEligible: true,
    assignmentMode: "RACE",
    hasAssignment: false,
    alreadyClaimedByPlayer: false,
    raceTaken: true,
  }).reason, "Someone already claimed that chore.");
  assert.equal(choreClaimGate({
    isActive: true,
    periodEligible: true,
    assignmentMode: "SPECIFIC",
    hasAssignment: false,
    alreadyClaimedByPlayer: false,
    raceTaken: false,
  }).reason, "That chore isn't assigned to you.");
});

test("family board lists SPECIFIC chores still open for someone", () => {
  const base = {
    isActive: true,
    periodEligible: true,
    assignedPlayerIds: ["willow", "finn"],
    activePlayerIds: ["willow", "finn", "sage"],
    claimedPlayerIdsThisPeriod: [] as string[],
    raceTaken: false,
  };
  assert.equal(
    choreOpenForFamily({ ...base, assignmentMode: "SPECIFIC" }),
    true,
  );
  assert.equal(
    choreOpenForFamily({
      ...base,
      assignmentMode: "SPECIFIC",
      claimedPlayerIdsThisPeriod: ["willow"],
    }),
    true,
    "Finn can still claim dishes",
  );
  assert.equal(
    choreOpenForFamily({
      ...base,
      assignmentMode: "SPECIFIC",
      claimedPlayerIdsThisPeriod: ["willow", "finn"],
    }),
    false,
  );
  assert.equal(
    choreOpenForFamily({
      ...base,
      assignmentMode: "SPECIFIC",
      assignedPlayerIds: ["willow"],
      claimedPlayerIdsThisPeriod: [],
    }),
    true,
    "Willow-only job still appears on the family corkboard",
  );
  assert.equal(
    choreOpenForFamily({
      ...base,
      assignmentMode: "RACE",
      raceTaken: true,
    }),
    false,
  );
  assert.equal(
    choreOpenForFamily({
      ...base,
      assignmentMode: "ALL",
      claimedPlayerIdsThisPeriod: ["willow", "finn"],
    }),
    true,
    "Sage has not claimed yet",
  );
});

test("honest skip reward is 1 shard; claim status includes SKIPPED", () => {
  assert.equal(SKIP_SHARD_REWARD, 1);
  assert.ok(CHORE_CLAIM_STATUSES.includes("SKIPPED"));
});

test("optional chores allow skip; must-do chores do not", () => {
  const skipOk = [
    "dishes-1-6",
    "take-out-trash",
    "empty-dishwasher",
    "do-homework",
    "clean-snack-mess",
    "clean-shoe-room",
    "clean-table",
  ];
  const skipNo = [
    "feed-dog-am",
    "feed-dog-pm",
    "walk-the-dog",
    "brush-teeth-am",
    "brush-teeth-bedtime",
    "make-your-bed",
    "hang-backpack",
    "shoes-on-rack",
    "water-bottle-backpack",
  ];
  for (const slug of skipOk) {
    const row = CHORE_CATALOG.find((r) => r.slug === slug);
    assert.ok(row, slug);
    assert.equal(row.allowsSkip, true, slug);
  }
  for (const slug of skipNo) {
    const row = CHORE_CATALOG.find((r) => r.slug === slug);
    assert.ok(row, slug);
    assert.equal(row.allowsSkip, false, slug);
  }
});
